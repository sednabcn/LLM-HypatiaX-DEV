"""
scripts/lib/config.py — the ONLY code in this project that parses config/*.yml.

Used two ways:
  1. As a library:  `from lib.config import Config` — generate_tables.py and
     generate_figures.py import this to resolve --experiment names, aliases,
     and shard glob patterns, instead of each script (or the CI workflow)
     re-implementing that lookup.
  2. As a CLI: `python -m lib.config <command> ...` — ci_postprocess.yml
     calls this instead of embedding the resolution/guard/sync-check logic
     as inline Python in the workflow YAML. One implementation, two callers,
     zero drift between "what the workflow thinks an experiment is" and
     "what the scripts think an experiment is".

Config directory layout (config/), each file owning ONE concern:
  experiments.yml   - experiment ID -> source dir, generator flags, aliases,
                       push-trigger paths
  guards.yml        - cross-experiment directory write-ownership rules
  outputs.yml       - results_root, on_missing_data policy, extra files to
                       stage per experiment
  shards.yml        - glob patterns for sharded/multi-file source data

Portability: to reuse this pipeline in a new project, only the four files
under config/ need to change. Nothing in this module, and nothing in
ci_postprocess.yml, should ever hardcode an experiment name or directory —
if you find yourself typing one into either, it belongs in config/ instead.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import re
import sys
from pathlib import Path
from typing import Optional

try:
    import yaml
except ImportError as e:  # pragma: no cover
    raise SystemExit("PyYAML is required: pip install PyYAML") from e


DEFAULT_CONFIG_DIR = Path(os.environ.get("PIPELINE_CONFIG_DIR", "config"))


class ConfigError(Exception):
    """Raised for any malformed or self-inconsistent config/*.yml content."""


def _load_yaml(path: Path) -> dict:
    if not path.is_file():
        raise ConfigError(f"missing config file: {path}")
    with path.open() as f:
        return yaml.safe_load(f) or {}


def _glob_to_regex(pattern: str) -> re.Pattern:
    """Translate a gitignore-style glob (supporting '**') to a regex.
    Shared by trigger-path matching; not a general-purpose glob library."""
    escaped = re.escape(pattern)
    escaped = escaped.replace(r"\*\*/", "(?:.*/)?")
    escaped = escaped.replace(r"\*\*", ".*")
    escaped = escaped.replace(r"\*", "[^/]*")
    return re.compile("^" + escaped + "$")


def _sha256(path: str) -> str:
    with open(path, "rb") as f:
        return hashlib.sha256(f.read()).hexdigest()


def _snapshot(path: str) -> dict:
    files = {}
    if os.path.isdir(path):
        for dirpath, _dirs, filenames in os.walk(path):
            for fn in filenames:
                fp = os.path.join(dirpath, fn)
                files[fp] = _sha256(fp)
    return files


class Config:
    """Reads config/experiments.yml + guards.yml + outputs.yml + shards.yml
    and answers every question the pipeline needs to ask of them."""

    def __init__(self, config_dir: "str | Path" = DEFAULT_CONFIG_DIR):
        self.dir = Path(config_dir)

        experiments_cfg = _load_yaml(self.dir / "experiments.yml")
        guards_cfg = _load_yaml(self.dir / "guards.yml")
        outputs_cfg = _load_yaml(self.dir / "outputs.yml")
        shards_cfg = _load_yaml(self.dir / "shards.yml")

        self.experiments: dict = experiments_cfg.get("experiments", {})
        self.aggregates: dict = experiments_cfg.get("aggregates", {})
        self.all_entries: dict = {**self.experiments, **self.aggregates}

        self.guards: list = guards_cfg.get("guards", [])

        self.results_root: str = outputs_cfg.get("results_root", "results")
        self.on_missing_data: str = outputs_cfg.get("on_missing_data", "warn_and_skip")
        self._extra_stage_files: dict = outputs_cfg.get("extra_stage_files", {})

        self._shards: dict = shards_cfg.get("shards", {})

        self._validate()

    # -- internal consistency checks, run once at load time --------------
    def _validate(self) -> None:
        dupe_aliases: dict[str, str] = {}
        for eid, entry in self.all_entries.items():
            for alias in entry.get("aliases", []):
                if alias in self.all_entries:
                    raise ConfigError(
                        f"alias '{alias}' on '{eid}' collides with a real "
                        f"experiment ID of the same name"
                    )
                if alias in dupe_aliases:
                    raise ConfigError(
                        f"alias '{alias}' is claimed by both "
                        f"'{dupe_aliases[alias]}' and '{eid}'"
                    )
                dupe_aliases[alias] = eid
        for guard in self.guards:
            for owner in guard.get("owners", []):
                if owner not in self.all_entries:
                    raise ConfigError(
                        f"guards.yml references unknown experiment/aggregate "
                        f"'{owner}' as an owner"
                    )
        for eid in self._extra_stage_files:
            if eid not in self.all_entries:
                raise ConfigError(
                    f"outputs.yml's extra_stage_files references unknown "
                    f"experiment '{eid}'"
                )
        for eid in self._shards:
            if eid not in self.all_entries:
                raise ConfigError(
                    f"shards.yml references unknown experiment '{eid}'"
                )

    # -- identity resolution -----------------------------------------------
    def resolve_id(self, raw: str) -> str:
        if raw in self.all_entries:
            return raw
        for eid, entry in self.all_entries.items():
            if raw in entry.get("aliases", []):
                return eid
        raise ConfigError(
            f"'{raw}' is not a known experiment ID or alias in "
            f"{self.dir / 'experiments.yml'}"
        )

    def is_aggregate(self, exp_id: str) -> bool:
        return exp_id in self.aggregates

    def all_ids(self) -> set:
        return set(self.all_entries)

    # -- path resolution -----------------------------------------------------
    def paths_for(self, raw_id: str) -> dict:
        exp_id = self.resolve_id(raw_id)
        entry = self.all_entries[exp_id]

        if self.is_aggregate(exp_id):
            figures_dir = entry["figures_dir"]
            tables_dir = entry.get("tables_dir")
            source_dir = figures_dir  # aggregates read their own figures dir
        else:
            source_dir = entry["source_dir"]
            figures_dir = f"{source_dir}/figures"
            tables_dir = f"{source_dir}/tables"

        return {
            "id": exp_id,
            "is_aggregate": self.is_aggregate(exp_id),
            "results_root": self.results_root,
            "source_dir_abs": f"{self.results_root}/{source_dir}",
            "figures_dir_abs": f"{self.results_root}/{figures_dir}",
            "tables_dir_abs": f"{self.results_root}/{tables_dir}" if tables_dir else "",
            "generates_tables": bool(entry.get("generates_tables", False)),
            "generates_figures": bool(entry.get("generates_figures", False)),
            "extra_stage_files": self._extra_stage_files.get(exp_id, []),
            "description": entry.get("description", exp_id),
        }

    def figures_deploy_sources(self) -> list[tuple]:
        """(experiment_id, figures_dir_abs) for every standard experiment
        that produces figures — what figures_deploy assembles from."""
        out = []
        for eid, entry in self.experiments.items():
            if entry.get("generates_figures"):
                out.append((eid, f"{self.results_root}/{entry['source_dir']}/figures"))
        return out

    # -- trigger-path matching (push auto-detect) ---------------------------
    def matches_trigger(self, exp_id: str, changed_path: str) -> bool:
        trig = self.all_entries[exp_id].get("trigger_paths", [])
        positives = [p for p in trig if not p.startswith("!")]
        negatives = [p[1:] for p in trig if p.startswith("!")]
        if any(_glob_to_regex(p).match(changed_path) for p in negatives):
            return False
        return any(_glob_to_regex(p).match(changed_path) for p in positives)

    def detect_from_changed_files(self, changed_files: list) -> Optional[str]:
        for path in changed_files:
            for eid in self.all_entries:
                if self.matches_trigger(eid, path):
                    return eid
        return None

    # -- shard patterns -------------------------------------------------------
    def shard_pattern_for(self, raw_id: str) -> Optional[dict]:
        exp_id = self.resolve_id(raw_id)
        return self._shards.get(exp_id)

    # -- guards -----------------------------------------------------------------
    def guarded_dirs_for(self, raw_id: str) -> list:
        """Absolute dirs `raw_id` must NOT write to (owned by others)."""
        exp_id = self.resolve_id(raw_id)
        dirs = []
        for guard in self.guards:
            if exp_id in guard["owners"]:
                continue
            dirs.extend(f"{self.results_root}/{d}" for d in guard["dirs"])
        return dirs

    def snapshot_guarded_dirs(self, raw_id: str) -> dict:
        return {path: _snapshot(path) for path in self.guarded_dirs_for(raw_id)}

    def guard_violations(self, before_snapshot: dict) -> list:
        return [path for path, before in before_snapshot.items()
                if _snapshot(path) != before]

    # -- CI-YAML/config drift check ------------------------------------------
    def validate_dispatch_sync(self, dispatch_options: set) -> list:
        config_ids = self.all_ids()
        msgs = []
        missing_from_dispatch = config_ids - dispatch_options
        missing_from_config = dispatch_options - config_ids
        if missing_from_dispatch:
            msgs.append(
                f"In config/ but NOT in workflow dispatch options: "
                f"{sorted(missing_from_dispatch)}"
            )
        if missing_from_config:
            msgs.append(
                f"In workflow dispatch options but NOT in config/: "
                f"{sorted(missing_from_config)}"
            )
        return msgs


# ===========================================================================
# CLI — lets ci_postprocess.yml call this module instead of embedding logic.
# All commands print GITHUB_OUTPUT-formatted `key=value` lines (or a single
# status line) to stdout; errors go to stderr as `::error::...` annotations
# and exit non-zero.
# ===========================================================================

def _print_kv(d: dict) -> None:
    for k, v in d.items():
        if isinstance(v, bool):
            v = str(v).lower()
        elif isinstance(v, (list, dict)):
            v = json.dumps(v)
        print(f"{k}={v}")


def _cmd_resolve(args, cfg: Config) -> None:
    if args.event == "workflow_dispatch":
        if not args.input:
            print("::error::--input is required for --event workflow_dispatch",
                  file=sys.stderr)
            sys.exit(1)
        try:
            exp_id = cfg.resolve_id(args.input)
        except ConfigError as e:
            print(f"::error::{e}", file=sys.stderr)
            sys.exit(1)
    else:
        exp_id = cfg.detect_from_changed_files(args.changed_file)
        if exp_id is None:
            print("::error::No changed file matched any experiment's "
                  "trigger_paths in config/experiments.yml.", file=sys.stderr)
            sys.exit(1)

    _print_kv(cfg.paths_for(exp_id))


def _cmd_validate_sync(args, cfg: Config) -> None:
    dispatch_options = {s for s in args.dispatch_options.split(",") if s}
    msgs = cfg.validate_dispatch_sync(dispatch_options)
    if msgs:
        print("::error::ci_postprocess.yml's workflow_dispatch options have "
              "drifted from config/experiments.yml:")
        for m in msgs:
            print(f"  {m}")
        print("Fix: update workflow_dispatch.inputs.experiment.options in "
              "ci_postprocess.yml to match config/experiments.yml.")
        sys.exit(1)
    print(f"OK — {len(cfg.all_ids())} experiment/aggregate IDs in sync "
          f"between config/experiments.yml and ci_postprocess.yml.")


def _cmd_guards_snapshot(args, cfg: Config) -> None:
    snap = cfg.snapshot_guarded_dirs(args.experiment)
    Path(args.out).write_text(json.dumps(snap))
    print(f"Guarding {len(snap)} directory(ies) not owned by '{args.experiment}'.")


def _cmd_guards_check(args, cfg: Config) -> None:
    before = json.loads(Path(args.snapshot).read_text())
    violations = cfg.guard_violations(before)
    if violations:
        print("::error::This run wrote into a directory it does not own:")
        for v in violations:
            print(f"  {v}")
        print("See config/guards.yml for the owning experiment(s).")
        sys.exit(1)
    print("OK — no guarded directory was touched by this run.")


def _cmd_figures_deploy_sources(args, cfg: Config) -> None:
    for eid, path in cfg.figures_deploy_sources():
        print(f"{eid}\t{path}")


def main() -> None:
    p = argparse.ArgumentParser(prog="python -m lib.config")
    p.add_argument("--config-dir", default=str(DEFAULT_CONFIG_DIR))
    sub = p.add_subparsers(dest="command", required=True)

    r = sub.add_parser("resolve", help="resolve an experiment ID to its paths")
    r.add_argument("--event", choices=["push", "workflow_dispatch"], required=True)
    r.add_argument("--input", default=None, help="dispatch input value")
    r.add_argument("--changed-file", action="append", default=[],
                   help="repeatable; changed file path for push auto-detect")

    v = sub.add_parser("validate-sync", help="check workflow dispatch options vs config")
    v.add_argument("--dispatch-options", required=True, help="comma-separated ID list")

    gs = sub.add_parser("guards-snapshot", help="hash-snapshot guarded dirs before a run")
    gs.add_argument("--experiment", required=True)
    gs.add_argument("--out", required=True)

    gc = sub.add_parser("guards-check", help="fail if a guarded dir changed since snapshot")
    gc.add_argument("--snapshot", required=True)

    sub.add_parser("figures-deploy-sources",
                    help="list (experiment, figures_dir) pairs figures_deploy assembles from")

    args = p.parse_args()
    try:
        cfg = Config(args.config_dir)
    except ConfigError as e:
        print(f"::error::{e}", file=sys.stderr)
        sys.exit(1)

    {
        "resolve": _cmd_resolve,
        "validate-sync": _cmd_validate_sync,
        "guards-snapshot": _cmd_guards_snapshot,
        "guards-check": _cmd_guards_check,
        "figures-deploy-sources": _cmd_figures_deploy_sources,
    }[args.command](args, cfg)


if __name__ == "__main__":
    main()
